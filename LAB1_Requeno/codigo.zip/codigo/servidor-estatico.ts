import * as http from 'http';
import * as fs from 'fs';
import * as path from 'path';

// Requisito 2: Escuchar en el puerto 3001
const PORT = 3001;

const servidor = http.createServer((req, res) => {
    // Requisito 4: Construir la ruta absoluta usando el módulo 'path'
    const archivo = path.join(__dirname, 'public', 'index (2).html');

    // Requisito 4: Usar el módulo 'fs' para leer el archivo
    fs.readFile(archivo, (error, contenido) => {
        if (error) {
            console.error('Error al leer el archivo HTML:', error);
            res.writeHead(500, { 'Content-Type': 'text/plain' });
            res.end('Error interno del servidor o archivo no encontrado.');
            return;
        }

        // Enviar el contenido del HTML con el código 200 (OK)
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(contenido);
    });
});

servidor.listen(PORT, () => {
    console.log(`[Ejercicio 1] Servidor estático corriendo en http://localhost:${PORT}`);
});