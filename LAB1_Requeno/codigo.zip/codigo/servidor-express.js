"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const helmet_1 = __importDefault(require("helmet"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const app = (0, express_1.default)();
// Puerto alternativo porque el 3000 está ocupado por otra instancia.
const PORT = 3002;
// MIDDLEWARES (Requisito 4: Seguridad)
// a) Instale y use helmet
app.use((0, helmet_1.default)());
// Habilitar la lectura de JSON en el cuerpo de las peticiones POST
app.use(express_1.default.json());
// b) Instale y use express-rate-limit (30 peticiones / minuto)
const limiter = (0, express_rate_limit_1.default)({
    windowMs: 1 * 60 * 1000, // 1 minuto
    max: 30, // 30 peticiones
    message: { error: 'Demasiadas peticiones, intenta de nuevo en un minuto.' }
});
app.use(limiter);
// DATOS (Memoria)
let usuarios = [
    { id: 1, nombre: 'Jefferson ALexander', email: 'Alex@gmail.com' },
    { id: 2, nombre: 'Pocho', email: 'pocho@gmail.com' },
    { id: 3, nombre: 'Ken Mejia', email: 'Ken@gmail.com' }
];
let nextId = 4; // Para el id autoincremental del POST
// RUTAS DINÁMICAS (Requisito 3)
// a) GET /api/usuarios: devuelve el arreglo de usuarios
app.get('/api/usuarios', (req, res) => {
    res.json(usuarios);
});
// b) GET /api/usuarios/:id devuelve el usuario específico o 404
app.get('/api/usuarios/:id', (req, res) => {
    const parametroId = req.params.id;
    const userId = typeof parametroId === 'string' ? parseInt(parametroId, 10) : NaN;
    const usuario = usuarios.find(u => u.id === userId);
    if (!usuario) {
        // Importante: El return evita que se siga ejecutando código
        res.status(404).json({ error: "Usuario no encontrado" });
        return;
    }
    res.json(usuario);
});
// c) POST /api/usuarios recibe {nombre, email} y agrega uno nuevo
app.post('/api/usuarios', (req, res) => {
    const { nombre, email } = req.body;
    // Validación: verificar existencia y que no estén vacíos
    if (!nombre || !email || nombre.trim() === '' || email.trim() === '') {
        res.status(400).json({ error: 'Faltan datos. El nombre y el email son obligatorios y no pueden estar vacíos.' });
        return;
    }
    const nuevoUsuario = {
        id: nextId++, // Asigna el id actual y luego le suma 1 para el siguiente
        nombre: nombre.trim(),
        email: email.trim()
    };
    usuarios.push(nuevoUsuario);
    res.status(201).json(nuevoUsuario);
});
// d) GET /api/health devuelve el status y timestamp
app.get('/api/health', (req, res) => {
    res.json({
        status: "OK",
        timestamp: new Date().toISOString()
    });
});
// MANEJO DE ERRORES requuisito 4
// c) Middleware de errores que nunca muestre el stack trace
app.use((err, req, res, next) => {
    // El stack trace solo se imprime en la terminal del servidor (para el programador)
    console.error('Error interno del servidor detectado:', err.stack);
    // El cliente solo recibe un mensaje genérico JSON
    res.status(500).json({ error: 'Ha ocurrido un error interno en el servidor.' });
});
// Inicialización
app.listen(PORT, () => {
    console.log(`[Ejercicio 2] Servidor Express corriendo en http://localhost:${PORT}`);
});
//# sourceMappingURL=servidor-express.js.map