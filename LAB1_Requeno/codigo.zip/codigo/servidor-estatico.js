"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const http = __importStar(require("http"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
// Requisito 2: Escuchar en el puerto 3001
const PORT = 3001;
const servidor = http.createServer((req, res) => {
    // Requisito 4: Construir la ruta absoluta usando el módulo 'path'
    const archivo = path.join(__dirname, 'public', 'index (2).html');
    // Requisito 4: Usar el módulo 'fs' para leer el archivo
    fs.readFile(archivo, (error, contenido) => {
        if (error) {
            console.error('Error al leer el archivo HTML:', error);
            res.writeHead(500, { 'Content-Type': 'text/plain' });
            res.end('Error interno del servidor o archivo no encontrado.');
            return;
        }
        // Enviar el contenido del HTML con el código 200 (OK)
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(contenido);
    });
});
servidor.listen(PORT, () => {
    console.log(`[Ejercicio 1] Servidor estático corriendo en http://localhost:${PORT}`);
});
//# sourceMappingURL=servidor-estatico.js.map